# TEMPLATE ONLY — NOT READY FOR FPGA PROGRAMMING.
# Confirm the exact Nexys A7 model/revision and use its official master XDC.
# Replace every placeholder with the correct package pin from that master XDC.

# Example structure (uncomment and fill in verified pin names):
# set_property PACKAGE_PIN <CLOCK_PIN> [get_ports clock_in]
# set_property IOSTANDARD LVCMOS33 [get_ports clock_in]
# create_clock -period 10.000 -name sys_clk [get_ports clock_in]
#
# set_property PACKAGE_PIN <RESET_BUTTON_PIN> [get_ports reset_in]
# set_property IOSTANDARD LVCMOS33 [get_ports reset_in]
#
# set_property PACKAGE_PIN <ENABLE_SWITCH_PIN> [get_ports enable_in]
# set_property IOSTANDARD LVCMOS33 [get_ports enable_in]
#
# set_property PACKAGE_PIN <RED_LED_PIN> [get_ports red_out]
# set_property IOSTANDARD LVCMOS33 [get_ports red_out]
# set_property PACKAGE_PIN <GREEN_LED_PIN> [get_ports green_out]
# set_property IOSTANDARD LVCMOS33 [get_ports green_out]
# set_property PACKAGE_PIN <YELLOW_LED_PIN> [get_ports yellow_out]
# set_property IOSTANDARD LVCMOS33 [get_ports yellow_out]
