# Simulation Results

## Testbench configuration

| Parameter | Simulation value |
|---|---:|
| Clock period | 10 ns |
| Clock frequency setting | 4 cycles per simulated second |
| RED duration | 2 simulated seconds |
| GREEN duration | 3 simulated seconds |
| YELLOW duration | 1 simulated second |

## Output sequence

| State | red_out | green_out | yellow_out | Duration |
|---|---:|---:|---:|---:|
| RED | 1 | 0 | 0 | 2 simulated seconds |
| GREEN | 0 | 1 | 0 | 3 simulated seconds |
| YELLOW | 0 | 0 | 1 | 1 simulated second |

The verified sequence is:

RED → GREEN → YELLOW → RED → GREEN → YELLOW ...

## Waveform checks

- `clk` is a periodic clock with a 10 ns period.
- Sequential logic is triggered on every positive edge (`posedge clk`).
- `reset` initializes the FSM to RED and clears the counters.
- `enable` allows the timer and state transitions to proceed.
- `red_out`, `green_out` and `yellow_out` indicate the active FSM state.
- The testbench checks that exactly one output is active during normal operation.

## Result

The testbench is configured to exercise repeated state transitions and check the one-hot traffic-light outputs. The waveform signal set is suitable for observing the complete RED, GREEN and YELLOW sequence in Vivado.
