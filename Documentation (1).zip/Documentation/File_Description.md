# File Description

- `RTL/traffic_light_controller.v`: synthesizable traffic-light FSM and timer.
- `Simulation/traffic_light_tb.v`: clock/reset/enable stimulus and output checks.
- `Documentation/Project_Overview.md`: project purpose, objectives and interface.
- `Documentation/Simulation_Results.md`: output states, timing settings and waveform checks.
- `Documentation/FPGA_Implementation.md`: Vivado FPGA design flow.
- `Results/Simulation_Output.txt`: output table and state sequence.
- `Results/Waveform_Signal_Guide.txt`: waveform signal names and `posedge clk` interpretation.
- `Constraints/traffic_light.xdc`: XDC constraint template to be completed for the exact board.
