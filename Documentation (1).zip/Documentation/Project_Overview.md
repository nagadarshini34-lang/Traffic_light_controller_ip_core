# Project Overview

## Traffic Light Controller IP Core

The project implements a three-light traffic controller using Verilog HDL and a finite state machine (FSM). The system controls RED, GREEN and YELLOW outputs in a repeating sequence.

**Sequence:** RED → GREEN → YELLOW → RED

### Design objectives
- Implement an FSM-based traffic controller.
- Use `always @(posedge clk)` for sequential state and counter updates.
- Generate timed state changes with a clock counter and seconds counter.
- Verify the three outputs using a Verilog testbench.
- Complete the Vivado FPGA design flow.

### Input and output interface
Inputs: `clk`, `reset`, `enable`

Outputs: `red_out`, `green_out`, `yellow_out`

The outputs are active-high. RED, GREEN and YELLOW are mutually exclusive in every valid state.
