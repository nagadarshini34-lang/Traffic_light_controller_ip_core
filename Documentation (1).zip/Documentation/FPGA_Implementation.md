# FPGA Implementation Summary

## Design
Traffic Light Controller using Verilog HDL and a three-state FSM.

## Vivado implementation flow
1. Create an RTL project and select the FPGA device used for the target board.
2. Add `traffic_light_controller.v` as a design source.
3. Add `traffic_light_tb.v` as a simulation source.
4. Run behavioral simulation and inspect the clock and traffic-light outputs.
5. Add the board-specific XDC pin assignments.
6. Run synthesis.
7. Run implementation.
8. Generate the bitstream.
9. Program the FPGA and verify the RED, GREEN and YELLOW LED sequence.

## Timing configuration
The RTL default parameters are set for a 100 MHz clock with RED = 5 seconds, GREEN = 5 seconds and YELLOW = 2 seconds. These values can be changed to match the target board clock and required signal timing.

## FPGA constraints
The XDC file contains the clock and I/O constraint structure. The PACKAGE_PIN values and I/O standards must correspond to the exact FPGA board and its official master constraints.

## Implementation checks
- Confirm the selected FPGA part matches the physical board.
- Confirm the clock input and clock period.
- Confirm the LED, reset and enable pin assignments.
- Check synthesis and implementation reports for errors and timing status.
- Generate the bitstream for the selected FPGA part.
