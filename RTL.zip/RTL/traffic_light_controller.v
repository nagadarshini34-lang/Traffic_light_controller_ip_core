module traffic_light_controller #(
    parameter integer CLK_FREQ=100_000_000,
    parameter integer RED_TIME=10,
    parameter integer GREEN_TIME=10,
    parameter integer YELLOW_TIME=3
)(
    input wire clock_in, reset_in, enable_in,
    output reg red_out, green_out, yellow_out
);
    localparam [1:0] RED=2'b00, GREEN=2'b01, YELLOW=2'b10;
    reg [1:0] state;
    reg [31:0] divider_count, second_count, state_duration;

    // Sequential registers update on the positive edge of clock_in.
    always @(posedge clock_in or posedge reset_in) begin
        if (reset_in) begin
            divider_count <= 0;
            second_count <= 0;
            state <= RED;
        end else if (enable_in) begin
            if (divider_count == CLK_FREQ-1) begin
                divider_count <= 0;
                if (second_count == state_duration-1) begin
                    second_count <= 0;
                    case (state)
                        RED: state <= GREEN;
                        GREEN: state <= YELLOW;
                        YELLOW: state <= RED;
                        default: state <= RED;
                    endcase
                end else second_count <= second_count + 1;
            end else divider_count <= divider_count + 1;
        end else divider_count <= 0;
    end

    always @(*) begin
        case (state)
            RED: state_duration=RED_TIME;
            GREEN: state_duration=GREEN_TIME;
            YELLOW: state_duration=YELLOW_TIME;
            default: state_duration=RED_TIME;
        endcase
    end

    always @(*) begin
        red_out=(state==RED);
        green_out=(state==GREEN);
        yellow_out=(state==YELLOW);
    end
endmodule
