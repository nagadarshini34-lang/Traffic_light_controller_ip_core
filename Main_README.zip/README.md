# TRAFFIC LIGHT CONTROLLER IP CORE

**Verilog HDL | Finite State Machine (FSM) | Xilinx Vivado | FPGA Implementation**

## 1. Project Overview

The Traffic Light Controller is a synchronous digital system designed using Verilog HDL. It controls three traffic signals—RED, GREEN and YELLOW—using a finite state machine and a clock-based timer.

The controller continuously follows this sequence:

**RED → GREEN → YELLOW → RED**

The design uses a parameterized clock divider and state timer, making the signal durations configurable for the target FPGA clock frequency.

## 2. Objectives

- Design a three-state traffic light controller using Verilog HDL.
- Implement the control sequence using an FSM.
- Use positive-edge-triggered sequential logic (`posedge clk`).
- Generate timed transitions between traffic-light states.
- Verify the operation through a Vivado behavioral simulation.
- Synthesize and implement the design for FPGA hardware.

## 3. Functional Description

### Inputs

| Signal | Description |
|---|---|
| `clk` | FPGA system clock |
| `reset` | Synchronous active-high reset |
| `enable` | Enables the timer and state transitions |

### Outputs

| Signal | Description |
|---|---|
| `red_out` | RED signal output, active high |
| `green_out` | GREEN signal output, active high |
| `yellow_out` | YELLOW signal output, active high |

### State/output table

| FSM state | red_out | green_out | yellow_out |
|---|---:|---:|---:|
| RED | 1 | 0 | 0 |
| GREEN | 0 | 1 | 0 |
| YELLOW | 0 | 0 | 1 |

Only one traffic-light output is active at a time.

## 4. FSM Operation

1. When reset is asserted, the FSM is initialized to RED and the counters are cleared.
2. When reset is released and enable is high, the clock counter begins counting on each rising edge of `clk`.
3. When the configured number of clock cycles has elapsed, the seconds counter is updated.
4. After the RED duration, the FSM moves to GREEN.
5. After the GREEN duration, the FSM moves to YELLOW.
6. After the YELLOW duration, the FSM returns to RED.
7. The sequence repeats continuously.

All sequential state and counter updates are triggered by `posedge clk`.

## 5. Timing Parameters

### Hardware defaults in RTL

| Parameter | Value |
|---|---:|
| Clock frequency | 100 MHz |
| RED duration | 5 seconds |
| GREEN duration | 5 seconds |
| YELLOW duration | 2 seconds |

### Accelerated testbench settings

| Parameter | Value |
|---|---:|
| Simulation clock period | 10 ns |
| Clock cycles per simulated second | 4 |
| RED duration | 2 simulated seconds |
| GREEN duration | 3 simulated seconds |
| YELLOW duration | 1 simulated second |

The testbench uses shorter parameter values so that multiple traffic-light cycles can be observed quickly in simulation.

## 6. Simulation and Waveform Verification

The testbench generates the clock, applies reset, enables the controller and monitors all three outputs.

Signals observed in the waveform:
- `clk`
- `reset`
- `enable`
- `red_out`
- `green_out`
- `yellow_out`

The waveform is inspected at the rising edges (`posedge clk`). The output sequence is verified as RED → GREEN → YELLOW → RED. The one-hot check verifies that exactly one traffic-light output is active during normal operation.

## 7. FPGA Design Flow

The design is taken through the standard Xilinx Vivado FPGA workflow:

1. Create the Vivado RTL project and select the target FPGA device.
2. Add the Verilog RTL design.
3. Add the Verilog testbench under Simulation Sources.
4. Run behavioral simulation and inspect the waveform.
5. Add the FPGA pin constraints.
6. Run synthesis.
7. Run implementation.
8. Generate the FPGA bitstream.
9. Program the target FPGA board and verify the LED outputs.

## 8. Repository File Description

| File | Purpose |
|---|---|
| `RTL/traffic_light_controller.v` | Synthesizable FSM-based Verilog design |
| `Simulation/traffic_light_tb.v` | Testbench for clock, reset, enable and output verification |
| `Documentation/Project_Overview.md` | Project description, objectives and design operation |
| `Documentation/Simulation_Results.md` | Simulation output sequence and waveform signal summary |
| `Documentation/FPGA_Implementation.md` | Vivado synthesis, implementation and bitstream flow |
| `Results/Simulation_Output.txt` | Tabulated simulation output sequence |
| `Results/Waveform_Signal_Guide.txt` | Signals and positive-edge waveform interpretation |
| `Constraints/traffic_light.xdc` | FPGA pin and clock constraint file |

## 9. Conclusion

The Traffic Light Controller demonstrates the use of Verilog HDL, finite state machine design, clock-based timing and positive-edge-triggered sequential logic. The controller generates the required RED, GREEN and YELLOW sequence and provides a structured design suitable for simulation, synthesis and FPGA implementation.
