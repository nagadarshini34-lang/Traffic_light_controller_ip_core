## Nexys A7 XDC TEMPLATE — not ready for bitstream generation
## Confirm exact board revision and use its official master XDC.
## Required ports: clock_in, reset_in, enable_in, red_out, green_out, yellow_out
## Copy the correct PACKAGE_PIN and IOSTANDARD lines from the official XDC.
## Example placeholders (do not leave placeholders active):
## set_property PACKAGE_PIN <CLOCK_PIN> [get_ports clock_in]
## set_property IOSTANDARD LVCMOS33 [get_ports clock_in]
## create_clock -period 10.000 -name sys_clk [get_ports clock_in]
## set_property PACKAGE_PIN <RESET_PIN> [get_ports reset_in]
## set_property PACKAGE_PIN <ENABLE_PIN> [get_ports enable_in]
## set_property PACKAGE_PIN <RED_LED_PIN> [get_ports red_out]
## set_property PACKAGE_PIN <GREEN_LED_PIN> [get_ports green_out]
## set_property PACKAGE_PIN <YELLOW_LED_PIN> [get_ports yellow_out]
