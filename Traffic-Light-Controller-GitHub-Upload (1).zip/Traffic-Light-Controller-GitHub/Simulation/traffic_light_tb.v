`timescale 1ns / 1ps
module traffic_light_tb;
    reg clock_in, reset_in, enable_in;
    wire red_out, green_out, yellow_out;
    localparam integer PERIOD=10;

    traffic_light_controller #(
        .CLK_FREQ(PERIOD), .RED_TIME(2),
        .GREEN_TIME(2), .YELLOW_TIME(1)
    ) dut (
        .clock_in(clock_in), .reset_in(reset_in), .enable_in(enable_in),
        .red_out(red_out), .green_out(green_out), .yellow_out(yellow_out)
    );

    // 10 ns clock period; posedge at 5, 15, 25, ... ns.
    initial clock_in=0;
    always #5 clock_in=~clock_in;

    initial begin
        reset_in=1; enable_in=0;
        #20; reset_in=0; enable_in=1;
        #1800; $finish;
    end

    initial
        $monitor("time=%0t clk=%b reset=%b enable=%b RED=%b GREEN=%b YELLOW=%b",
                 $time,clock_in,reset_in,enable_in,red_out,green_out,yellow_out);
endmodule
