# Traffic Light Controller IP Core using Verilog HDL

FSM-based traffic signal controller implemented in Verilog HDL for Xilinx Vivado.

## Operation
The controller repeats the sequence **RED → GREEN → YELLOW → RED**.
- RED: stop
- GREEN: go
- YELLOW: prepare to stop

## Interface

| Signal | Direction | Description |
|---|---|---|
| `clock_in` | Input | FPGA clock |
| `reset_in` | Input | Active-high asynchronous reset |
| `enable_in` | Input | Enables the sequence |
| `red_out` | Output | Red lamp control |
| `green_out` | Output | Green lamp control |
| `yellow_out` | Output | Yellow lamp control |

## Timing parameters
Default values assume a 100 MHz clock: `CLK_FREQ=100000000`, `RED_TIME=10`, `GREEN_TIME=10`, `YELLOW_TIME=3`. The testbench overrides these values to shorten simulation time.

## Repository contents
- `RTL/traffic_light_controller.v` — synthesizable RTL
- `Simulation/traffic_light_tb.v` — simulation testbench
- `Constraints/nexys_a7_constraints_template.xdc` — pin-constraint template
- `Documentation/FSM_State_Diagram.pdf` — FSM sequence
- `Documentation/System_Block_Diagram.pdf` — system architecture
- `Results/expected_waveform_posedge.png` — expected waveform illustration

## Run in Vivado
1. Create an RTL project for your exact FPGA part.
2. Add the RTL file to Design Sources.
3. Add the testbench to Simulation Sources and set it as simulation top.
4. Run **Run Behavioral Simulation**.
5. Add `clock_in`, `reset_in`, `enable_in`, `red_out`, `green_out`, `yellow_out` to the waveform.
6. Run synthesis and inspect the synthesized schematic.
7. Use **Tools → Create and Package New IP** to package the controller.

## FPGA implementation
The supplied board photo appears to show a Nexys A7. Confirm the exact board revision and FPGA part. Use the official Nexys A7 master XDC and map the clock, reset, enable, and LED pins from that file. Then run synthesis, implementation, generate bitstream, and program the FPGA.

**Important:** The included XDC is only a template and has no guessed package pin assignments. This starter repository does not contain a generated `.bit` file. Add a bitstream only after successful implementation for your actual board.

## Waveform note
The waveform image is an expected timing illustration, not a captured Vivado simulator screenshot. Replace it with your own Vivado waveform capture before claiming simulation evidence.

## Author
Add your name, register number, department, and institution here.
